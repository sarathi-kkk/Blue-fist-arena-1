# Blue Fist Arena

A standalone installable browser fighting-game prototype based on the uploaded motion references.

## Included
- 2-player local multiplayer
- VS CPU mode
- Punch, kick and heavy attacks inspired by the supplied move sheet
- Escape/dash with afterimage trails inspired by the supplied escape reference
- Cinematic impact burst and screen shake inspired by the first reference
- Blue-energy hand special move
- Health, energy, timer and K.O. state
- Mobile touch controls
- PWA manifest + service worker for installation/offline play

## Run
Open `index.html` in a browser. For best PWA/service-worker behavior, serve the folder from a local HTTP server.

## Controls
P1: WASD, F punch, G kick, H heavy, J special, K escape.
P2: Arrow keys, N punch, M kick, comma heavy, period special, slash escape.
R rematches after K.O.
